package ViewModel;

import Model.Event;
import Model.EventRepository;
import Model.EventStatus;
import Model.Category;
import Model.CategoryService;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class CreateEventViewModel
{
    private static final DateTimeFormatter DATE_TIME_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private CreateEventForm form;
    private EventRepository repository;
    private EventValidator validator;
    private List<FieldError> lastErrors;

    private CategoryService categoryService;

    public CreateEventViewModel(EventRepository repository, CategoryService categoryService)
    {

        this.repository = repository;
        this.categoryService = categoryService;
        this.form = new CreateEventForm();
        this.validator = new EventValidator();
        this.lastErrors = new ArrayList<>();
    }

    public void updateField(String field, String value)
    {
        switch (field)
        {
            case "name":         form.setName(value); break;
            case "description":  form.setDescription(value); break;
            case "dateTime":     form.setDateTime(value); break;
            case "venue":        form.setVenue(value); break;
            case "address":      form.setAddress(value); break;
            case "category":     form.setCategoryName(value); break;
            case "zipCode":      form.setZipCode(value); break;
            case "ticketPrice":  form.setTicketPrice(value); break;
            case "totalTickets": form.setTotalTickets(value); break;
            case "imageURL":     form.setImageURL(value); break;
            default:
                System.err.println("Unknown form field: " + field);
        }
    }

    public boolean onCreateEvent()
    {
        lastErrors = validator.validate(form);

        if (!lastErrors.isEmpty())
        {
            return false;
        }

        // Parse optional zip code
        Integer zipCode = null;
        String rawZip = form.getZipCode() == null ? "" : form.getZipCode().trim();
        if (!rawZip.isEmpty())
        {
            try { zipCode = Integer.parseInt(rawZip); }
            catch (NumberFormatException e)
            {
                lastErrors.add(new FieldError("zipCode", "City ZIP must be a 4-digit number"));
                return false;
            }
        }

        // Validation passed, safe to parse and build the Event
        Event event = new Event(
                0, // new event, no ID yet
                form.getName().trim(),
                form.getDescription().trim(),
                LocalDateTime.parse(form.getDateTime().trim(), DATE_TIME_FORMAT),
                form.getVenue().trim(),
                form.getAddress().trim(),
                form.getCategoryName().trim(),
                Double.parseDouble(form.getTicketPrice().trim()),
                Integer.parseInt(form.getTotalTickets().trim()),
                0, // ticketsSold = 0 for new event
                form.getImageURL().trim().isEmpty() ? null : form.getImageURL().trim(),
                EventStatus.PUBLISHED,
                zipCode
        );

        try
        {
            repository.save(event);
            // reset form for next entry
            this.form = new CreateEventForm();
            return true;
        }
        catch (SQLException e)
        {
            lastErrors.add(new FieldError("_general",
                    "Could not save event: " + e.getMessage()));
            return false;
        }
    }

    public List<Category> getAllCategories()
    {
        try
        {
            return categoryService.findAll();
        }
        catch (java.sql.SQLException e)
        {
            return new ArrayList<>();
        }
    }

    public List<FieldError> getLastErrors()
    {
        return lastErrors;
    }

    public CreateEventForm getForm()
    {
        return form;
    }
}